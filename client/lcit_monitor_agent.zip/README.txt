Cai dat:
sudo dpkg -i lcit_monitor_agent_deb.deb

Cau hinh:
nano /etc/default/lcit-monitor-agent

Khoi dong lai:
systemctl restart lcit-monitor-agent

Cai dat:
sudo HOSTNAME="<Ten_Host_Name>" PLATFORM="<Ten_Nen_Tang>" dpkg -i lcit_monitor_agent_deb.deb

Cau hinh:
nano /etc/default/lcit-monitor-agent

Khoi dong lai:
systemctl restart lcit-monitor-agent
